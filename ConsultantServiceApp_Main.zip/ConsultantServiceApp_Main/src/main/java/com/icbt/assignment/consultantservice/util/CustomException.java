package com.icbt.assignment.consultantservice.util;

public class CustomException extends RuntimeException{
	public CustomException(String message) {
		super(message);
	}

}
